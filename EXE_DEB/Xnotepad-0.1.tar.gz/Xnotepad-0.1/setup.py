from setuptools import setup

setup(
    name="Xnotepad",
    version="0.1",
    packages=[""],
    scripts=["Main.py"],
    description="A simple Notepad",
    long_description="A longer description of your project",
    install_requires=[
        "PyQt5",
        "fastapi",
        # دیگر وابستگی‌های لازم
    ],
)
